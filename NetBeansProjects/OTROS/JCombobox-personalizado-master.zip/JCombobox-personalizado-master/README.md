# JCombobox-personalizado
Creación de una lista desplegable(JCombobox) personalizado para poder optimizar las búsquedas a la base de datos

<p>Adjuntamos las <b>librerias</b> requeridas para ejecutar el proyecto correctamenta ya que estamos trabajando con <b>base de datos</b>, 
  igualmente adjuntamos el archivo <b>sql</b> donde esta nuestra <b>base de datos</b>, deben tomar este archivo e <b>importarlo</b> a su gestor de <b>base de datos</b> de confianza</p>

<h3> Te invito a seguir nuestro blog: https://uh-tis.blogspot.com/ (SOFTWARE GALAXIA) </h3>
<h3> Canal de Youtube: https://www.youtube.com/SoftwareGalaxiaTV </h3>
