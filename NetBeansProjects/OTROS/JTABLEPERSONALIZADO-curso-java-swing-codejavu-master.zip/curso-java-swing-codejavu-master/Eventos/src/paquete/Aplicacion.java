package paquete;

public class Aplicacion {
	public static void main(String args[]) {
		Ventana ventana;
		ventana = new Ventana();
		ventana.setVisible(true);
	}
}
