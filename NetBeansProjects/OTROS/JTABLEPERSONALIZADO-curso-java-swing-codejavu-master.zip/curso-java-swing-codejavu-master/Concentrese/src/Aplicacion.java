
public class Aplicacion {

	public static void main(String[] args) {
		VentanaPrincipal miVentana=new VentanaPrincipal();
		miVentana.setVisible(true);
		
	}

}
