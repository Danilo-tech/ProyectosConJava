package aplicacion;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		VentanaPrincipal miVentanaPrincipal= new VentanaPrincipal();
		miVentanaPrincipal.setVisible(true);
	}

}
