package controlador;

public class Principal {

	/**
	 * Falta Validar que si no hay conexion la establezca
	 * @param args
	 */
	public static void main(String[] args) {
		Aplicacion miAplicacion=new Aplicacion();
		miAplicacion.iniciarSistema();
	}

}
