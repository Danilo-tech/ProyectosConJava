package principal;

import ventana.Ventana;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Ventana miVentana= new Ventana();
		miVentana.setVisible(true);
	}

}
