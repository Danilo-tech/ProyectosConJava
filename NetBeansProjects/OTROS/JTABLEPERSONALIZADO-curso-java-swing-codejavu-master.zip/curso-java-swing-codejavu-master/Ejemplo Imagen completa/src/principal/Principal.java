package principal;

import ventana.Panel;
import ventana.VentanaPrincipal;

/**
 * @author HENAO
 *
 */
public class Principal {

	public static void main(String[] args) {
		/**Declaramos el objeto*/
				
		VentanaPrincipal miVentanaPrincipal;
		/**Instanciamos el objeto*/
		miVentanaPrincipal= new VentanaPrincipal();
		/**Hacemos que se cargue la ventana*/
		miVentanaPrincipal.setVisible(true);	
		
		
		
	}
}
