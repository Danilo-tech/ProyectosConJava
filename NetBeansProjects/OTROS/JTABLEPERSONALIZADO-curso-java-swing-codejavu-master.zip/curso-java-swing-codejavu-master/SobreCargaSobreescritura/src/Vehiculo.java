
public class Vehiculo {
	
	protected String prender(){
		
		return "encendido en la clase padre";
		
	}

}
