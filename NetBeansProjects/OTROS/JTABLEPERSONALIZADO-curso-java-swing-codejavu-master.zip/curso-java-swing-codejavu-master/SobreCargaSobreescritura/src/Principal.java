
public class Principal {
	
	public static void main(String a[]){
		
		Vehiculo mVe= new Vehiculo();
		System.out.println(mVe.prender());
		Vehiculo miCarro= new Carro();
		System.out.println(miCarro.prender());
	}

}
