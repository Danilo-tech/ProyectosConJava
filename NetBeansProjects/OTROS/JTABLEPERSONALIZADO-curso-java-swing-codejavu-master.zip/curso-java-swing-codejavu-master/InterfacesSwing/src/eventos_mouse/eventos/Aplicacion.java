package eventos_mouse.eventos;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Aplicacion
{
public static void main(String args[])
{
Ventana ventana;
ventana=new Ventana();
}
}
