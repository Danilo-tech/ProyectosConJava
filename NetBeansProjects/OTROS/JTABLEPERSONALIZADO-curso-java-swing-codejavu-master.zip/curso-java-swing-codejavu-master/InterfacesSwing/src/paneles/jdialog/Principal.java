package paneles.jdialog;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		VentanaConfirmacion miVentana=new VentanaConfirmacion();
		miVentana.setVisible(true);
	}

}
