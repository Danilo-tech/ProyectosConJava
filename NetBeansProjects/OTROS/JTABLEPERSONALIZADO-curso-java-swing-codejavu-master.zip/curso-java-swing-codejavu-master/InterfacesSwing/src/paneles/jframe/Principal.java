package paneles.jframe;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ClaseFrame miFrame= new ClaseFrame();
		miFrame.setVisible(true);
	}

}
