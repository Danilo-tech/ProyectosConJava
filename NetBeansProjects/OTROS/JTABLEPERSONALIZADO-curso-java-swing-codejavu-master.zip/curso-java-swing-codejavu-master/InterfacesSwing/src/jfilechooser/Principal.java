package jfilechooser;

public class Principal {

	public static void main(String[] args) {
		ClaseFrame miVentana = new ClaseFrame();
		miVentana.setVisible(true);
	}
}
