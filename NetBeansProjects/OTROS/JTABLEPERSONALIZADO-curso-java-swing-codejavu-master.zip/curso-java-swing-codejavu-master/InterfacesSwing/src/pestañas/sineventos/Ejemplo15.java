package pesta�as.sineventos;

public class Ejemplo15
{
    public static void main ( String args [ ] )
    {
    	Ventana15 miVentana;
    	
    	miVentana = new Ventana15 ( );
    }
}