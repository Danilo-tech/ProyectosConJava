/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Casa
 */
public class barra {

    
    public static void main(String[] args) {
        presentacion pre= new presentacion();
        pre.setVisible(true);
        ventana1 iniciar= new ventana1();
        try{
            for(int i=0; i<=100; i++){
                Thread.sleep(40);
                pre.porcentaje.setText(Integer.toString(i)+"%");
                pre.barra.setValue(i);
                
                if(i==100){
                    pre.setVisible(false);
                    iniciar.setVisible(true);
                }
            }
        }catch (Exception e){
        }
    }
    
}
